Diablo-NX - A port of Devilution to the Nintendo Switch

Ported by MVG in 2019

Release History

V0.95
=====

More bug fixes. Thanks rsn887 and erfg12!

- Prevent "spell not rdy" speech on exit dialog
- Map L/R/A to char/inv/select spell, closer to PS1
- Map B button to cancel in menu, and A to OK
- Prevent walking with dpad while talking to people
- Allow B button to skip intro (in addition to plus)
- Support physical USB keyboards
- Implement touch controls
- Improve event code, fix touch controls pointer missing
- Ensure touch keyboard fails gracefully without softlock
- Swap A/B in menu so B is OK, A is cancel
- Remove hacks that are not neccessary with new event handling
- Use SDL_GameController for portability, make touch portable
- Simplify controller switch statements
- Use SDL Game Controller also for menu navigation

V0.94
=====

More bug fixes. Thanks rsn887!

- Left stick click for quest log
- Y in inventory to read books
- Fix infinite stats


V0.93
=====

lots of bug fixes! Thanks erfg12!

- Fixed attack/pickup/open actions
- Fixed left/right/up/down movements
- Fixed inventory and hotspell snap grid
- Fixed towner chat
- Plus opens menu, Minus opens automap
- Changed readme to show Windows and MacOS compilation instructions
- D-pad emulates joystick
- Automap moves with right joystick when open
- Controller buttons now closely mimic PS1 controller setup (please don't let ppl change this again)
- Added lots of SWITCH definitions to hopefully get it closer to merging with master code

V0.92
=====

- movies are now working
 
V0.91
=====

- analog right stick mouse control
- map right mouse button to ZL
- map the 'heal potion' hotkey to A

thanks rsn8887!



How To Play
===========

Extract contents of diablo-nx.zip release into SDMC:\switch\diablo-nx
Copy DIABDAT.MPQ from original Diablo game disc or GOG version.
Launch diablo-nx.nro
Enjoy :)

Controls
========

Left Analog : Move Hero
B : Attack
Y : Open Chest/Talk/Pick Up
X : Inventory
R : Character
Right Analog : Simulate Mouse
ZR : Left Mouse Click
ZL : Drink Heal Potion
Minus : Escape to Menu

Notes
=====
There are lots of bugs.